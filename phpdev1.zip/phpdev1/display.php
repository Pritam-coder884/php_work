<?php
include 'dbcon.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
      integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <style>
        .position{
            position:absolute;
            right:5px;
            top:10px;
        }
    </style>   

</head>
<body>
    <button class="btn btn-success position"><a href="user.php" class="text-light">Add More Products</a></button>
    <table class="table table-hover my-5 mx-5">
    <thead>
        <tr>
        <th scope="col">Id</th>
        <th scope="col">Name</th>
        <th scope="col">Price</th>
        <th scope="col">Description</th>
        <th scope="col">Image</th>
        <th scope="col">Opertaions</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $sql = "Select * from `myProducts`";
        $result = mysqli_query($con,$sql);
        if($result){
            while($row=mysqli_fetch_assoc($result)){
                $id=$row['id'];
                $name=$row['name'];
                $price=$row['price'];
                $description=$row['description'];
                $image = explode(',', $row['image']);
                echo '
                <tr>
                <td>'.$id.'</td>
                <td>'.$name.'</td>
                <td>'.$price.'</td>
                <td>'.$description.'</td>
                <td>';
                foreach($image as $image) {
                    echo '<img style="height:50px;width:100px;" src="'.$image.'">';
                }
                echo '</td>
                <td>
                    <button class="btn btn-warning">
                        <a href="update.php?updateid='.$id.' " class="text-light"><i class="fa fa-solid fa-pen-to-square"></i></a>
                    </button>
                    <button class="btn btn-danger">
                        <a href="delete.php?deleteid='.$id.' " class="text-light"><i class="fa fa-solid fa-trash"></i></a>
                    </button>
                </td>
                </tr>
                ';
                }
            }
        ?>
    </tbody>

</table>
</body>
</html>