<?php
include 'dbcon.php';
if(isset($_POST['submit'])){
    $name=$_POST['name'];
    $price=$_POST['price'];
    $description=$_POST['description'];
    $file=$_FILES['image'];

    foreach($file['name'] as $key => $value){
      $filename = $file['name'][$key];
      $filepath = $file['tmp_name'][$key];
      $fileerror = $file['error'][$key];
      if($fileerror == 0){
        $destfile = 'upload/'.$filename;
        move_uploaded_file($filepath, $destfile);  

        $sql = "INSERT INTO `myProducts` (name, price, description, image) 
        VALUES ('$name','$price','$description','$destfile')";     
        $result = mysqli_query($con,$sql);
        if($result){
            header('location:display.php');
        }
        else{
            die(mysqli_error($con));
        }
      }
    }

    
}
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <style>
      * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        /* background-color: rgba(4, 34, 61, 0.682); */
        background-color:gray;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI",
          Roboto, Oxygen, Ubuntu, Cantarell, "Open Sans", "Helvetica Neue",
          sans-serif;
      }
      body {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      .contact_form {
        padding: 15px 75px;
        height: 100%;
        background-color:black;
        border-radius: 10px;
        width: 600px;
        font-size: 25px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
      }
      .contact_form h1 {
        color: #fff;
        background-color: transparent;
        flex: 1;
        text-decoration: underline;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: auto;
        font-size: 60px;
      }
      .contact_form input,
      .contact_form textarea {
        width: 100%;
        margin-top: 20px;
        padding: 10px;
        font-size: 16px;
        border: none;
        box-shadow: 0 -2px 2px #6c6b6b;
        border-radius: 4px;
        background-color: #fff;
      }
      .contact_form input:focus,
      .contact_form textarea:focus {
        outline: none;
      }
      .img_input {
        display: none;
      }
      label {
        width: 100%;
        margin-top: 20px;
        padding: 10px 20px;
        /* color: #555; */
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 17px;
        border-radius: 5px;
        box-shadow: 0 -2px 2px #6c6b6b;
        background-color: #fff;
        color: #1e1d1d !important;
      }
      button {
        width: 30%;
        padding: 10px 20px;
        font-weight: bold;
        margin-top: 30px;
        font-size: 18px;
        border: none;
        box-shadow: 0 0 4px #aaa;
        border-radius: 4px;
        background-color:blue;
        color: #fff;
      }
      button:hover {
        cursor: pointer;
      }
    </style>
  </head>
  <body>
    <form method="POST" class="contact_form" enctype="multipart/form-data" >
      <h1>Product Details</h1>
      <!-- <input type="number" name="id" placeholder="ID..." /> -->
      <input type="text" name="name" placeholder="Name..." />
      <input type="number" name="price" placeholder="Price..." />
      <textarea
        name="description"
        id=""
        cols="30"
        rows="10"
        placeholder="Description..."
      ></textarea>
      <!-- <input class="img_input" type="file" name="image" multiple /> -->
      <label for="img_input">Choose an image</label>
      <input type="file" name="image[]" id="img_input" class="img_input" multiple />
      <button class="submit_button" name="submit">Submit</button>
    </form>
  </body>
</html>
