<?php 

$con = new mysqli('localhost','root','','mydatabase');
if(!$con){
    die(mysqli_error($con));
}
// if($con){
//     echo "Connection Successful";
// }
// else{
//     die(mysqli_error($con));
// }
?> 